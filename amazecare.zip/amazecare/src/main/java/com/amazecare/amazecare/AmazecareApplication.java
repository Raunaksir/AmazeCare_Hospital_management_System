package com.amazecare.amazecare;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AmazecareApplication {

	public static void main(String[] args) {
		SpringApplication.run(AmazecareApplication.class, args);
	}

}
