package com.amazecare.controller;

import com.amazecare.model.MedicalRecord;
import com.amazecare.repository.MedicalRecordRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/medical-records")
@CrossOrigin
public class MedicalRecordController {

    @Autowired
    private MedicalRecordRepository medicalRecordRepository;

    @PostMapping("/add")
    public MedicalRecord addRecord(@RequestBody MedicalRecord record) {
        return medicalRecordRepository.save(record);
    }

    @GetMapping("/patient/{patientId}")
    public List<MedicalRecord> getByPatient(@PathVariable int patientId) {
        return medicalRecordRepository.findByPatientId(patientId);
    }

    @GetMapping("/doctor/{doctorId}")
    public List<MedicalRecord> getByDoctor(@PathVariable int doctorId) {
        return medicalRecordRepository.findByDoctorId(doctorId);
    }
}
