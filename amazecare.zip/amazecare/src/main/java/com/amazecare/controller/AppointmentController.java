package com.amazecare.controller;

import com.amazecare.model.Appointment;
import com.amazecare.repository.AppointmentRepository;
import com.amazecare.service.AppointmentService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/appointments")
@CrossOrigin
public class AppointmentController {

    @Autowired
    private AppointmentRepository appointmentRepository;

    @PostMapping("/book")
    public Appointment bookAppointment(@RequestBody Appointment appointment) {
        return appointmentRepository.save(appointment);
    }

    @GetMapping("/doctor/{doctorId}")
    public List<Appointment> getAppointmentsByDoctor(@PathVariable int doctorId) {
        return appointmentRepository.findByDoctorId(doctorId);
    }

    @GetMapping("/patient/{patientId}")
    public List<Appointment> getAppointmentsByPatient(@PathVariable int patientId) {
        return appointmentRepository.findByPatientId(patientId);
    }
    @Autowired
    private AppointmentService appointmentService;

    @PostMapping("/book")
    public Appointment book(@RequestBody Appointment appt) {
        return appointmentService.bookAppointment(appt);
    }

    @PutMapping("/{id}/status")
    public Appointment updateStatus(@PathVariable int id, @RequestParam String status) {
        Appointment appointment = appointmentRepository.findById(id).orElse(null);
        if (appointment != null) {
            appointment.setStatus(status);
            return appointmentRepository.save(appointment);
        }
        return null;
    }
}
