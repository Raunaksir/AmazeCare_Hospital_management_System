package com.amazecare.service;

import com.amazecare.model.Doctor;
import com.amazecare.repository.DoctorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DoctorService {

    @Autowired
	protected DoctorRepository doctorRepository;

    public Doctor registerDoctor(Doctor doctor) {
        if (doctorRepository.findByEmail(doctor.getEmail()) != null) {
            throw new RuntimeException("Doctor already registered with this email");
        }
        return doctorRepository.save(doctor);
    }

    public List<Doctor> getAllDoctors() {
        return doctorRepository.findAll();
    }

    public Doctor getDoctorById(int id) {
        return doctorRepository.findById(id).orElse(null);
    }

    public Doctor getByEmail(String email) {
        return doctorRepository.findByEmail(email);
    }
}
