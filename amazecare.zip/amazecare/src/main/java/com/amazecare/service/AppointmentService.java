package com.amazecare.service;

import com.amazecare.model.Appointment;
import com.amazecare.repository.AppointmentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

@Service
public class AppointmentService {

    @Autowired
    public AppointmentRepository appointmentRepository;

    // Book appointment 
    public Appointment bookAppointment(Appointment appointment) {
        LocalDate apptDate = appointment.getAppointmentDate();
        LocalTime apptTime = appointment.getAppointmentTime();

        // case 1: Cannot book in the past
        if (apptDate.isBefore(LocalDate.now())) {
            throw new RuntimeException("Cannot book appointment in the past");
        }

        // case 2: Doctor cannot be double booked
        List<Appointment> doctorAppointments = appointmentRepository.findByDoctorId(appointment.getDoctor().getId());
        for (Appointment a : doctorAppointments) {
            if (a.getAppointmentDate().equals(apptDate) && a.getAppointmentTime().equals(apptTime)) {
                throw new RuntimeException("Doctor is already booked at this time");
            }
        }

        // case 3: Patient cannot be double booked
        List<Appointment> patientAppointments = appointmentRepository.findByPatientId(appointment.getPatient().getId());
        for (Appointment a : patientAppointments) {
            if (a.getAppointmentDate().equals(apptDate) && a.getAppointmentTime().equals(apptTime)) {
                throw new RuntimeException("Patient already has an appointment at this time");
            }
        }

        // All checks passed, save appointment
        return appointmentRepository.save(appointment);
    }

    // View by doctor
    public List<Appointment> getAppointmentsByDoctor(int doctorId) {
        return appointmentRepository.findByDoctorId(doctorId);
    }

    // View by patient
    public List<Appointment> getAppointmentsByPatient(int patientId) {
        return appointmentRepository.findByPatientId(patientId);
    }

    // Update appointment status
    public Appointment updateStatus(int id, String status) {
        Appointment appt = appointmentRepository.findById(id).orElse(null);
        if (appt != null) {
            appt.setStatus(status);
            return appointmentRepository.save(appt);
        }
        throw new RuntimeException("Appointment not found");
    }

    // Cancel appointment
    public void cancelAppointment(int id) {
        Appointment appt = appointmentRepository.findById(id).orElse(null);
        if (appt != null) {
            appt.setStatus("Cancelled");
            appointmentRepository.save(appt);
        } else {
            throw new RuntimeException("Appointment not found to cancel");
        }
    }
}
