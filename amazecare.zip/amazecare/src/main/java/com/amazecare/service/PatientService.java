package com.amazecare.service;

import com.amazecare.model.Patient;
import com.amazecare.repository.PatientRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PatientService {

    @Autowired
	protected PatientRepository patientRepository;

    public Patient registerPatient(Patient patient) {
        // Basic rule: check for existing email
        if (getPatientRepository().findByEmail(patient.getEmail()) != null) {
            throw new RuntimeException("Email already registered");
        }
        return getPatientRepository().save(patient);
    }

    public List<Patient> getAllPatients() {
        return getPatientRepository().findAll();
    }

    public Patient getPatientById(int id) {
        return getPatientRepository().findById(id).orElse(null);
    }

    public Patient getByEmail(String email) {
        return getPatientRepository().findByEmail(email);
    }

	public PatientRepository getPatientRepository() {
		return patientRepository;
	}

	public void setPatientRepository(PatientRepository patientRepository) {
		this.patientRepository = patientRepository;
	}
}
