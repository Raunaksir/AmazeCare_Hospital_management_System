package com.amazecare.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.amazecare.model.Appointment;

import java.util.List;

public interface AppointmentRepository extends JpaRepository<Appointment, Integer> {
    List<Appointment> findByDoctorId(int doctorId);
    List<Appointment> findByPatientId(int patientId);
}
