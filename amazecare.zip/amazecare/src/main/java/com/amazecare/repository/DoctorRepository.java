package com.amazecare.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.amazecare.model.Doctor;

public interface DoctorRepository extends JpaRepository<Doctor, Integer> {
    Doctor findByEmail(String email);
}
