package com.amazecare.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.amazecare.model.Admin;

public interface AdminRepository extends JpaRepository<Admin, Integer> {
    Admin findByEmail(String email);
}
