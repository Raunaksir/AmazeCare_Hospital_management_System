package com.amazecare.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.amazecare.model.MedicalRecord;

import java.util.List;

public interface MedicalRecordRepository extends JpaRepository<MedicalRecord, Integer> {
    List<MedicalRecord> findByPatientId(int patientId);
    List<MedicalRecord> findByDoctorId(int doctorId);
}
