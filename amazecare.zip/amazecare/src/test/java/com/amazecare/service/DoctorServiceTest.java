package com.amazecare.service;

import com.amazecare.model.Doctor;
import com.amazecare.repository.DoctorRepository;
import org.junit.jupiter.api.Test;
import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

public class DoctorServiceTest {

    @Test
    public void testRegisterDoctor_success() {
        DoctorRepository mockRepo = mock(DoctorRepository.class);
        DoctorService service = new DoctorService() {{
            doctorRepository = mockRepo;
        }};

        Doctor doctor = new Doctor(0, "Dr. Strange", "Neuro", 10, "MBBS", "Consultant", "doc@mail.com", "pwd");
        when(mockRepo.findByEmail("doc@mail.com")).thenReturn(null);
        when(mockRepo.save(doctor)).thenReturn(doctor);

        Doctor result = service.registerDoctor(doctor);
        assertEquals("Dr. Strange", result.getName());
        verify(mockRepo).save(doctor);
    }

    @Test
    public void testRegisterDoctor_emailExists_throwsException() {
        DoctorRepository mockRepo = mock(DoctorRepository.class);
        DoctorService service = new DoctorService() {{
            doctorRepository = mockRepo;
        }};

        when(mockRepo.findByEmail("doc@mail.com")).thenReturn(new Doctor(0, null, null, 0, null, null, null, null));

        RuntimeException ex = assertThrows(RuntimeException.class, () ->
                service.registerDoctor(new Doctor(0, "Dr. Strange", "Neuro", 10, "MBBS", "Consultant", "doc@mail.com", "pwd")));

        assertEquals("Doctor already registered with this email", ex.getMessage());
    }
}
