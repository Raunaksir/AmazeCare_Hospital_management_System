package com.amazecare.service;

import com.amazecare.model.Patient;
import com.amazecare.repository.PatientRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

public class PatientServiceTest {

    private PatientRepository mockRepo;
    private PatientService service;

    @BeforeEach
    public void setUp() {
        mockRepo = mock(PatientRepository.class);
        service = new PatientService();
        service.patientRepository = mockRepo; // Field injection
    }

    private Patient createPatient() {
        return new Patient(
                0,
                "Asha Kumari",
                "2000-05-10",
                "Female",
                "9876543210",
                "asha@amazecare.com",
                "asha123",
                "Fever and headache"
        );
    }

    @Test
    public void testRegisterPatient_success() {
        Patient patient = createPatient();

        when(mockRepo.findByEmail(patient.getEmail())).thenReturn(null);
        when(mockRepo.save(patient)).thenReturn(patient);

        Patient result = service.registerPatient(patient);

        assertNotNull(result);
        assertEquals("Asha Kumari", result.getFullName());
        verify(mockRepo, times(1)).save(patient);
    }

    @Test
    public void testRegisterPatient_emailExists_throwsException() {
        Patient patient = createPatient();

        when(mockRepo.findByEmail(patient.getEmail())).thenReturn(new Patient(0, null, null, null, null, null, null, null));

        RuntimeException ex = assertThrows(RuntimeException.class, () -> service.registerPatient(patient));
        assertEquals("Email already registered", ex.getMessage());
        verify(mockRepo, never()).save(any());
    }

    @Test
    public void testGetAllPatients_returnsList() {
        when(mockRepo.findAll()).thenReturn(List.of(createPatient()));

        List<Patient> patients = service.getAllPatients();
        assertEquals(1, patients.size());
        assertEquals("Asha Kumari", patients.get(0).getFullName());
    }

    @Test
    public void testGetPatientById_found() {
        Patient patient = createPatient();
        patient.setId(101);

        when(mockRepo.findById(101)).thenReturn(java.util.Optional.of(patient));

        Patient result = service.getPatientById(101);
        assertNotNull(result);
        assertEquals("Asha Kumari", result.getFullName());
    }

    @Test
    public void testGetPatientById_notFound_returnsNull() {
        when(mockRepo.findById(999)).thenReturn(java.util.Optional.empty());

        Patient result = service.getPatientById(999);
        assertNull(result);
    }

    @Test
    public void testGetByEmail_found() {
        Patient patient = createPatient();
        when(mockRepo.findByEmail(patient.getEmail())).thenReturn(patient);

        Patient result = service.getByEmail(patient.getEmail());
        assertEquals("Asha Kumari", result.getFullName());
    }

    @Test
    public void testGetByEmail_notFound_returnsNull() {
        when(mockRepo.findByEmail("unknown@mail.com")).thenReturn(null);

        Patient result = service.getByEmail("unknown@mail.com");
        assertNull(result);
    }
}
