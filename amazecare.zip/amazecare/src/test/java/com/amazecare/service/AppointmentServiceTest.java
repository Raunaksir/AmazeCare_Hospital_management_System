package com.amazecare.service;

import com.amazecare.model.Appointment;
import com.amazecare.model.Doctor;
import com.amazecare.model.Patient;
import com.amazecare.repository.AppointmentRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class AppointmentServiceTest {

    private AppointmentRepository mockRepo;
    private AppointmentService service;

    @BeforeEach
    public void setUp() {
        mockRepo = mock(AppointmentRepository.class);
        service = new AppointmentService();
        service.appointmentRepository = mockRepo;
    }

    private Appointment createAppointment(LocalDate date, LocalTime time) {
        Patient patient = new Patient(0, null, null, null, null, null, null, null);
        patient.setId(1);
        patient.setFullName("John Doe");

        Doctor doctor = new Doctor(0, null, null, 0, null, null, null, null);
        doctor.setId(1);
        doctor.setName("Dr. Smith");

        Appointment appt = new Appointment();
        appt.setPatient(patient);
        appt.setDoctor(doctor);
        appt.setAppointmentDate(date);
        appt.setAppointmentTime(time);
        appt.setStatus("Scheduled");

        return appt;
    }

    @Test
    public void testBookAppointment_success() {
        Appointment appt = createAppointment(LocalDate.now().plusDays(1), LocalTime.of(10, 0));

        when(mockRepo.findByDoctorId(1)).thenReturn(List.of());
        when(mockRepo.findByPatientId(1)).thenReturn(List.of());
        when(mockRepo.save(appt)).thenReturn(appt);

        Appointment result = service.bookAppointment(appt);

        assertNotNull(result);
        assertEquals("Scheduled", result.getStatus());
        verify(mockRepo).save(appt);
    }

    @Test
    public void testBookAppointment_pastDate_throwsException() {
        Appointment appt = createAppointment(LocalDate.now().minusDays(1), LocalTime.of(10, 0));

        RuntimeException ex = assertThrows(RuntimeException.class, () -> service.bookAppointment(appt));
        assertEquals("Cannot book appointment in the past", ex.getMessage());
    }

    @Test
    public void testBookAppointment_doctorDoubleBooking_throwsException() {
        Appointment existing = createAppointment(LocalDate.now().plusDays(1), LocalTime.of(10, 0));
        Appointment newAppt = createAppointment(LocalDate.now().plusDays(1), LocalTime.of(10, 0));

        when(mockRepo.findByDoctorId(1)).thenReturn(List.of(existing));
        when(mockRepo.findByPatientId(1)).thenReturn(List.of());

        RuntimeException ex = assertThrows(RuntimeException.class, () -> service.bookAppointment(newAppt));
        assertEquals("Doctor is already booked at this time", ex.getMessage());
    }

    @Test
    public void testBookAppointment_patientDoubleBooking_throwsException() {
        Appointment existing = createAppointment(LocalDate.now().plusDays(1), LocalTime.of(10, 0));
        Appointment newAppt = createAppointment(LocalDate.now().plusDays(1), LocalTime.of(10, 0));

        when(mockRepo.findByDoctorId(1)).thenReturn(List.of());
        when(mockRepo.findByPatientId(1)).thenReturn(List.of(existing));

        RuntimeException ex = assertThrows(RuntimeException.class, () -> service.bookAppointment(newAppt));
        assertEquals("Patient already has an appointment at this time", ex.getMessage());
    }

    @Test
    public void testUpdateStatus_success() {
        Appointment appt = createAppointment(LocalDate.now().plusDays(1), LocalTime.of(11, 0));
        appt.setId(101);

        when(mockRepo.findById(101)).thenReturn(java.util.Optional.of(appt));
        when(mockRepo.save(appt)).thenReturn(appt);

        Appointment updated = service.updateStatus(101, "Completed");

        assertEquals("Completed", updated.getStatus());
    }

    @Test
    public void testCancelAppointment_success() {
        Appointment appt = createAppointment(LocalDate.now().plusDays(1), LocalTime.of(11, 0));
        appt.setId(102);

        when(mockRepo.findById(102)).thenReturn(java.util.Optional.of(appt));

        service.cancelAppointment(102);

        assertEquals("Cancelled", appt.getStatus());
        verify(mockRepo).save(appt);
    }

    @Test
    public void testUpdateStatus_appointmentNotFound_throwsException() {
        when(mockRepo.findById(999)).thenReturn(java.util.Optional.empty());

        RuntimeException ex = assertThrows(RuntimeException.class, () -> service.updateStatus(999, "Completed"));
        assertEquals("Appointment not found", ex.getMessage());
    }

    @Test
    public void testCancelAppointment_appointmentNotFound_throwsException() {
        when(mockRepo.findById(999)).thenReturn(java.util.Optional.empty());

        RuntimeException ex = assertThrows(RuntimeException.class, () -> service.cancelAppointment(999));
        assertEquals("Appointment not found to cancel", ex.getMessage());
    }
}
