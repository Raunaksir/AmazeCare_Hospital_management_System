package com.amazecare.amazecare;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AmazecareApplicationTests {

	@Test
	void contextLoads() {
	}

}
